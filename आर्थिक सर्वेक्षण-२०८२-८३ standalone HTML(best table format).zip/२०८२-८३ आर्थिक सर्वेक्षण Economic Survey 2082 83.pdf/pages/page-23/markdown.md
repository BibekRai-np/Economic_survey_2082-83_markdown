FATF Financial Action Task Force

FCHV App Female Community Health Volunteer Application

FM Frequency modulation

FNMIS Foreign National Management Information System

GDP Gross Domestic Product

GFS Government Finance Statistics

GHG Greenhouse Gas

GNI Gross National Income

go-AML Anti-Money Laundering System

GPA Grade Point Average

HAI Human Assets Index

HDI Human Development Index

HIV Human Immunodeficiency Virus

HLA Human Leukocyte Antigen

IMF International Monetary Fund

Inc. Incorporated

IP Internet Protocol

IPFMS Integrated Public Financial Management Services

IPPU Industrial Process and Product Uses

IRR Internal Rate of Return

ISO International Organization for Standardization

KV Kilo Volt

LDC Least Developed Country

LIBOR London Interbank Offered Rate

LMBIS Line Ministry Budget Information System

LPG Liquefied Petroleum Gas

LRIMS Land Records Information Management System

LULUCF Land Use, Land Use Change and Forestry

xviii