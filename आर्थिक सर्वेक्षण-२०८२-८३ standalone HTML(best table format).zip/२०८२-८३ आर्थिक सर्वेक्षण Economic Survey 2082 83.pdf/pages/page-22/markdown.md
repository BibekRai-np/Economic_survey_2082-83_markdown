छोटकरी रूप

[tbl-6.html](tbl-6.html)

xvii