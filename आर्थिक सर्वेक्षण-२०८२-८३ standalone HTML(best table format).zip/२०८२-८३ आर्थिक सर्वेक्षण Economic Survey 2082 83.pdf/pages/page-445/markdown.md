१४२

# अनुसूची ९.३: ऊर्जा खपतको विवरण

[tbl-389.html](tbl-389.html)

स्रोत: ऊर्जा, जनस्रोत तथा सिलाई जनगारायण, २०८२
Toll: Terms of Oil Equivalent