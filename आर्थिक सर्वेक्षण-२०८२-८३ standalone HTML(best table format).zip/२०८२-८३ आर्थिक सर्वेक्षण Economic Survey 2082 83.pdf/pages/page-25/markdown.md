xx

SCADA	Supervisory Control and Data Acquisition
SDG	Sustainable Development Goals
SDR	Special Drawing Rights
SEE	Secondary Education Examination
SMS	Short Message Service
SuTRA	Subnational Treasury Regulatory Application
T-Bond	Treasury Bond
TBM	Tunnel Boring Machine
ToE	Tonne of Oil Equivalent
TPS	True Potato Seed
USD	United States Dollar
VHF/UHF	Very High Frequency / Ultra High Frequency
WMO	World Meteorological Organization
WPAN	Withholding permanent Account Number