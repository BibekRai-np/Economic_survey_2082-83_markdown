xix

MDR-TB Multidrug Resistant Tuberculosis
NALCIS National Land Commission Information System
NARC Nepal Agricultural Research Council
NDC Nationally Determined Contributions
NELIS Nepal Land Information System
NEPLAS Nepal Laboratory Accreditation System
NEPSE Nepal Stock Exchange
OTC Over The Counter
PALMA PALMA Ratio (a measure of income inequality)
PAM Public Access Model
PAMS Public Assets Management System
PBS Pre-Basic Seed
PCPS Primary Commodity Price System
PDS Public Distribution System
PNCPS Perpetual Non-Cumulative Preference Share
POS Point of Sale
PPAN Personal Permanent Account Number
PPP Purchasing Power Parity
PPR Peste des Petits Ruminants
PTMC Percutaneous Transvenous Mitral Commissurotomy
QR Code Quick Response (Code)
RBPR Rapid Bio-Pesticide Residue
REDD+ Reducing Emissions from Deforestation and Forest Degradation
REMIS Regional Integrated Multi-Hazard Early Warning System
RMIS Revenue Management Information System
RTGS Real Time Gross Settlement
SAMi Safer Migration
S&amp;P Standard &amp; Poor's